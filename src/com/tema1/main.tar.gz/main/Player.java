package com.tema1.main;

import java.util.*;
import java.util.Collections;
import java.util.Map;


public class Player {
    private String strategy;
    private boolean isSheriff;
    private Card cards = new Card();
    private int pocket;

    public Player() {
        strategy = null;
        isSheriff = false;
        pocket = 80;
    }

    public Player(String strategy, Map<Integer, Integer> playerCards) {
        this.strategy = strategy;
        this.cards = new Card(playerCards);
        isSheriff = false;
        pocket = 80;
    }

    public Player(String strategy) {
        this.strategy = strategy;
    }

    public String getStrategy() {
        return strategy;
    }

    public void setStrategy(String strategy) {
        this.strategy = strategy;
    }

    public boolean isSheriff() {
        return isSheriff;
    }

    public final boolean getSheriff() {
        return this.isSheriff;
    }


    public void setSheriff(boolean sheriff) {
        isSheriff = sheriff;
    }

    public void setPlayerCards(List<Integer> gameCards) {
        int i = 0;
        for (int card : gameCards) {
            if (i == 10)
                break;
            this.cards.getCards().put(card, Collections.frequency(gameCards.subList(0, 10), card));
            i++;
        }
        gameCards.subList(0, 10).clear();
    }

    public void basicSetBag() {
        if(this.cards.isAllIllegals()) {
            cards.getMostProfit();
        }
        if(!this.cards.isAllIllegals()) {
            cards.removeIllegals();
            cards.mostFrequent();
            cards.getMostProfit();
        }
    }

    public void setBag(int round) {

        if (strategy.equals("basic")) {
            basicSetBag();
            return;
        }
        if (strategy.equals("greedy")) {
            if(round % 2 == 0) {
                basicSetBag();
                if(cards.bagSize() < 8)
                    cards.addIllegal();
                return ;
            }
            basicSetBag();
            return;
        }
        if (strategy.equals("bribed")) {
            if(!(cards.isAllIllegals())) {
                basicSetBag();
                return;
            }
            cards.getMostProfit();
        }
    }



    @Override
    public String toString() {
        String cards = this.cards.getCards().toString();

        return "" + strategy + "\t:" + cards ;

    }
}
